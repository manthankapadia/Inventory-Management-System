package media;

/**
 *
 */
public class userNameMedia {
    
   String Id;
   String usrName;

    /**
     *
     */
    public userNameMedia() {
    }

    /**
     *
     * @param Id
     */
    public userNameMedia(String Id) {
        this.Id = Id;
    }

    /**
     *
     * @param id
     * @param usrName
     */
    public userNameMedia(String id, String usrName) {
        this.Id = id;
        this.usrName = usrName;
    }

    /**
     *
     * @return
     */
    public String getId() {
        return Id;
    }

    /**
     *
     * @param id
     */
    public void setId(String id) {
        this.Id = id;
    }

    /**
     *
     * @return
     */
    public String getUsrName() {
        return usrName;
    }

    /**
     *
     * @param usrName
     */
    public void setUsrName(String usrName) {
        this.usrName = usrName;
    }
    
}
