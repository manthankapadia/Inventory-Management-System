package model.Getway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import dataBase.DBProperties;
import dataBase.SQLightConnection;
import model.DAL.MysqlConnector;

/**
 *
 * 
 */
public class MySqlConnectorGetway {

    SQLightConnection qLightConnection = new SQLightConnection();
    Connection con = qLightConnection.sqliteConnection();
    PreparedStatement pst;
    ResultSet rs;
    
    DBProperties dBProperties = new DBProperties();
    String db = dBProperties.loadPropertiesFile();

    /**
     *
     * @param connector
     */
    public void save(MysqlConnector connector) {
        try {
            pst = con.prepareStatement("insert into mysqlInfo_mk values(?,?,?,?,?)");
            pst.setInt(1, 1);
            pst.setString(2, connector.hostName);
            pst.setString(3, connector.portName);
            pst.setString(4, connector.userName);
            pst.setString(5, connector.password);
            pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(MySqlConnectorGetway.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *
     * @param connector
     */
    public void view(MysqlConnector connector) {
        try {
            pst = con.prepareStatement("select * from mysqlInfo_mk where Id=1");
            rs = pst.executeQuery();
            while(rs.next()){
                connector.hostName = rs.getString(2);
                connector.portName = rs.getString(3);
                connector.userName = rs.getString(4);
                connector.password = rs.getString(5);
            }
        } catch (SQLException ex) {
            Logger.getLogger(MySqlConnectorGetway.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
