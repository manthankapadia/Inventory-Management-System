package model.List;

/**
 *
 * 
 */
public class ListEmployee {
    
    
    public String employeeId;
    public String employeeName;

    /**
     *
     * @param employeeId
     * @param employeeName
     */
    public ListEmployee(String employeeId, String employeeName) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
    }

    /**
     *
     * @return
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /**
     *
     * @param employeeId
     */
    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    /**
     *
     * @return
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     *
     * @param employeeName
     */
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }
    
}
