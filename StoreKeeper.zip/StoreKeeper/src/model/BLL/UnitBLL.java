package model.BLL;

import model.DAL.Unit;
import model.Getway.UnitGetway;

/**
 * 
 */
public class UnitBLL {
    
    UnitGetway unitGetway = new UnitGetway();
    
    /**
     *
     * @param unit
     * @return
     */
    public Object save(Unit unit){
        if(unitGetway.isUniqName(unit)){
            unitGetway.save(unit);
        }
        return unit;
    }

    /**
     *
     * @param unit
     * @return
     */
    public Object delete(Unit unit){
        if(unitGetway.isNotUse(unit)){
            unitGetway.delete(unit);
        }
        return unit;
    }
}
