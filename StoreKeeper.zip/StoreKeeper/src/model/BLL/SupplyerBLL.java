package model.BLL;

import model.DAL.Supplyer;
import model.Getway.SupplyerGetway;

/**
 * 
 */
public class SupplyerBLL {
    
    SupplyerGetway supplyerGetway = new SupplyerGetway();

    /**
     *
     */
    public void save(){
        
    }
    
    /**
     *
     * @param supplyer
     * @return
     */
    public Object delete(Supplyer supplyer){
        if(supplyerGetway.isNotUse(supplyer)){
            supplyerGetway.delete(supplyer);
        }else{
            
        }
        return supplyer;
    }
}
