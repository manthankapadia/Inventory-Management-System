package model.BLL;

/**
 * 
 */
public class UserBLL {
}
