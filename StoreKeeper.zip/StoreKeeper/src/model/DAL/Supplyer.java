package model.DAL;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import model.List.ListSupplyer;

/**
 * 
 */
public class Supplyer {

    public String id;
    public String supplyerName;
    public String supplyerContactNumber;
    public String supplyerAddress;
    public String supplyerDescription;
    public String creatorId;
    public String date;
    public ObservableList<ListSupplyer> supplyerDetails = FXCollections.observableArrayList();




}
