package model.DAL;

/**
 *
*/
public class MysqlConnector {
    
    public String hostName;
    public String portName;
    public String userName;
    public String password;
    
}
