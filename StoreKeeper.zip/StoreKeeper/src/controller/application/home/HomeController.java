package controller.application.home;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import dataBase.DBConnection;
import dataBase.DBProperties;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import model.Getway.CurrentProductGetway;

/**
 * FXML Controller class
 */
public class HomeController implements Initializable {
    @FXML
    private Label lblTotalItem;
    @FXML
    private Label lblStockValue;
    @FXML
    private Label lblTotalSupplier;
    @FXML
    private Label lblTotalEmployee;
    
    DBConnection dbCon = new DBConnection();
    Connection con;
    PreparedStatement pst;
    ResultSet rs;
    @FXML
    private Label lblTotalSell;
    @FXML
    private Label lblSellValue;
    @FXML
    private Label lblOrgName;
    @FXML
    private Text txtOrgAddress;
    @FXML
    private Text txtorgPhoneNumber;
    
    DBProperties dBProperties = new DBProperties();
    String db = dBProperties.loadPropertiesFile();

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        totalCount();
        valueCount();
    }    
    
    /**
     *
     */
    public void valueCount(){
        con = dbCon.geConnection();
        try {
            pst = con.prepareStatement("select sum(PursesPrice) from "+db+".Products_mk");
            rs = pst.executeQuery();
            while (rs.next()) {
                lblStockValue.setText(""+ rs.getInt(1));
            }
            con.close();
            pst.close();
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(CurrentProductGetway.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     *
     */
    public void totalCount(){
        con = dbCon.geConnection();
        try {
            pst = con.prepareStatement("select count(*) from "+db+".Sell_mk");
            rs = pst.executeQuery();
            while (rs.next()) {
                lblTotalSell.setText(""+rs.getInt(1));
            }
            pst = con.prepareStatement("select count(*) from "+db+".Products_mk");
            rs = pst.executeQuery();
            while(rs.next()){
                lblTotalItem.setText(""+rs.getInt(1));
            }
            pst = con.prepareStatement("select sum(TotalPrice) from "+db+".Sell_mk");
            rs = pst.executeQuery();
            while(rs.next()){
                lblSellValue.setText(""+rs.getInt(1));
            }
            pst = con.prepareStatement("select count(*) from "+db+".User_mk");
            rs = pst.executeQuery();
            while(rs.next()){
                lblTotalEmployee.setText(""+rs.getInt(1));
            }
            pst = con.prepareStatement("select count(*) from "+db+".Supplyer_mk");
            rs = pst.executeQuery();
            while(rs.next()){
                lblTotalSupplier.setText(""+rs.getInt(1));
            }
            pst =con.prepareStatement("select * from "+db+".Organize_mk where Id=1");
            rs = pst.executeQuery();
            while(rs.next()){
                lblOrgName.setText(rs.getString(2)!=null?rs.getString(2):"");
                txtOrgAddress.setText(rs.getString(5)!=null?rs.getString(5):"");
                txtorgPhoneNumber.setText(rs.getString(4)!=null?rs.getString(4):"");
            }
            con.close();
            pst.close();
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(CurrentProductGetway.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
