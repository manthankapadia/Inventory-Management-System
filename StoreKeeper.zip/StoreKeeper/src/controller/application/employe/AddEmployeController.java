package controller.application.employe;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import custom.CustomTf;
import dataBase.DBConnection;
import dataBase.DBProperties;
import javafx.beans.binding.BooleanBinding;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.StageStyle;
import media.userNameMedia;
import model.DAL.Users;
import model.Getway.UsersGetway;

/**
 * FXML Controller class
 */
public class AddEmployeController implements Initializable {

    @FXML
    private TextField tfUserName;
    @FXML
    private TextField tfFullName;
    @FXML
    private TextField tfEmail;
    @FXML
    private Button btnAttachImage;
    @FXML
    private Button btnSave;
    @FXML
    private TextField tfPhone;
    @FXML
    private TextField tfSalary;
    @FXML
    private TextField tfPassword;
    @FXML
    private TextArea taAddress;
    @FXML
    private ImageView imvUsrImg;
    
    private File file;
    private BufferedImage bufferedImage;
    private Image image;
    
    private String imagePath;
    private String usrId;
    
    private userNameMedia nameMedia;

    /**
     *
     */
    @FXML
    public Button btnClrUsrName;

    /**
     *
     */
    @FXML
    public Button btnClrFullName;

    /**
     *
     */
    @FXML
    public Button btnClrEmail;

    /**
     *
     */
    @FXML
    public Button btnClrPhone;

    /**
     *
     */
    @FXML
    public Button btnClrSalary;

    /**
     *
     */
    @FXML
    public Button btnClrPassword;
    
    DBProperties dBProperties = new DBProperties();
    String db = dBProperties.loadPropertiesFile();

    Users users = new Users();
    UsersGetway usersGetway = new UsersGetway();

    /**
     *
     * @return
     */
    public userNameMedia getNameMedia() {
        return nameMedia;
    }

    /**
     *
     * @param nameMedia
     */
    public void setNameMedia(userNameMedia nameMedia) {
        usrId = nameMedia.getId();
        this.nameMedia = nameMedia;
    }

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        CustomTf cTf = new CustomTf();
        cTf.clearTextFieldByButton(tfUserName, btnClrUsrName);
        cTf.clearTextFieldByButton(tfFullName, btnClrFullName);
        cTf.clearTextFieldByButton(tfEmail, btnClrEmail);
        cTf.clearTextFieldByButton(tfPhone, btnClrPhone);
        cTf.clearTextFieldByButton(tfSalary, btnClrSalary);
        cTf.clearTextFieldByButton(tfPassword, btnClrPassword);

        cTf.numaricTextfield(tfSalary);
        
        BooleanBinding binding = tfUserName.textProperty().isEmpty()
                .or(tfFullName.textProperty().isEmpty()
                .or(tfPhone.textProperty().isEmpty())
                .or(tfPassword.textProperty().isEmpty()));
        btnSave.disableProperty().bind(binding);
    }    

    @FXML
    private void btnAttachImageOnAction(ActionEvent event) throws IOException {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("JPG (Joint Photographic Group)", "*.jpg"),
                new FileChooser.ExtensionFilter("JPEG (Joint Photographic Experts Group)", "*.jpeg"),
                new FileChooser.ExtensionFilter("PNG (Portable Network Graphics)", "*.png")
        );

        fileChooser.setTitle("Choise a Image File");

        file = fileChooser.showOpenDialog(null);

        if (file != null) {
            System.out.println(file);
            bufferedImage = ImageIO.read(file);
            image = SwingFXUtils.toFXImage(bufferedImage, null);
            imvUsrImg.setImage(image);
            imagePath = file.getAbsolutePath();
        }
    }

    @FXML
    private void btnSaveOnAction(ActionEvent event) {
        Boolean validity = isValidated(tfPhone,tfEmail);
        if(validity){
            users.userName = tfUserName.getText();
            users.fullName = tfFullName.getText();
            users.emailAddress = tfEmail.getText();
            users.contactNumber = tfPhone.getText();
            users.salary = tfSalary.getText();
            users.address = taAddress.getText();
            users.password = tfPassword.getText();
            users.imagePath = imagePath;
            users.creatorId = usrId;
            usersGetway.save(users);
            basicPermission();
        }else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setHeaderText("Data is not saved");
            alert.initStyle(StageStyle.UNDECORATED);
            alert.showAndWait();     
        }
    }

    
    private void basicPermission(){
        DBConnection dbCon = new DBConnection();
        Connection con;
        ResultSet rs;
        PreparedStatement pst;
        con = dbCon.geConnection();
        try {
            pst = con.prepareStatement("Select Id FROM "+db+".User_mk where UsrName=?");
            pst.setString(1, tfUserName.getText());
            rs = pst.executeQuery();
            while (rs.next()) {
                pst = con.prepareStatement("insert into "+db+".UserPermission_mk values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                pst.setString(1, null);
                pst.setInt(2, 0);
                pst.setInt(3, 0);
                pst.setInt(4, 0);
                pst.setInt(5, 0);
                pst.setInt(6, 0);
                pst.setInt(7, 0);
                pst.setInt(8, 0);
                pst.setInt(9, 0);
                pst.setInt(10, 0);
                pst.setInt(11, 0);
                pst.setInt(12, 0);
                pst.setInt(13, 0);
                pst.setInt(14, 0);
                pst.setInt(15, 0);
                pst.setInt(16, 0);
                pst.setInt(17, 0);
                pst.setInt(18, 0);
                pst.setInt(19, 0);
                pst.setInt(20, rs.getInt("Id"));

                pst.executeUpdate();

            }

        } catch (SQLException ex) {
            Logger.getLogger(AddEmployeController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     *
     * @param phone
     * @param email
     * @return
     */
    public boolean isValidated(TextField phone, TextField email) {
         boolean isValid = false;
        if (phone.getText()!=null && !phone.getText().isEmpty() && phone.getText().length()!=10){
                
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("ERROR : Enter a valid phone number.");
            alert.setContentText("Please check the length");
            alert.initStyle(StageStyle.UNDECORATED);
            alert.showAndWait();

            isValid = false;
        } else if (!checkNumeric(phone)){
            
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("ERROR : Enter a valid phone number");
            alert.setContentText("All characters are to be numeric");
            alert.initStyle(StageStyle.UNDECORATED);
            alert.showAndWait();     
            isValid=false;
        }else if(email.getText()==null || email.getText().isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("ERROR : Enter an email id");
            alert.initStyle(StageStyle.UNDECORATED);
            alert.showAndWait();     
            
            isValid = false;
        } else if (!checkEmail(email)){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("ERROR : Enter a valid email id");
            alert.initStyle(StageStyle.UNDECORATED);
            alert.showAndWait();     
            isValid = false;
        }else{
            isValid=true;
        }
        
        return isValid;
    }
     
    private boolean checkNumeric(TextField phone){
        Pattern p= Pattern.compile("[0-9]+");
        Matcher m = p.matcher(phone.getText());
        
        if(m.find() && m.group().equals(phone.getText())){
            return true;
        }else {
            return false;
        }      
    }
    
    private boolean checkEmail(TextField email){
        Pattern p= Pattern.compile("[a-zA-Z0-9][a-zA-Z0-9._]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
        Matcher m = p.matcher(email.getText());
        
        if(m.find() && m.group().equals(email.getText())){
            return true;
        }else {
            return false;
        }      
    }
    
}
